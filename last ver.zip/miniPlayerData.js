klynt.miniPlayerData = {
    "thanksForWatchingWording": "Thanks for watching!",
    "resumePlaybackWording": "Resume playback?",
    "downloadAppWording": "Download App",
    "fullscreenInfoWording": "This program will launch in fullscreen",
    "yesWording": "Yes",
    "title": "site",
    "thumbnail": "Medias/Photos/school.jpg",
    "noWording": "No",
    "analyticsKey": "",
    "launchAppWording": "Then Launch Project",
    "url": "",
    "redirectToMobileApp": "auto",
    "description": ""
}